<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\PelanggaranController;
use App\Http\Controllers\API\RPLController;
use App\Http\Controllers\API\AllJurusanController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// Route::post('login', 'AuthController@login');
// Route::middleware('auth:api')->group(function () {
// Route::post('logout', 'AuthController@logout');});

Route::middleware(['web', 'auth'])->group(function () {
    // Rute-rute yang memerlukan otentikasi di sini
});

Route::post('/login', function (Request $request) {

        $email = $request->input('email');
        $password = $request->input('password');
    // Proses otentikasi pengguna di sini
    if (Auth::attempt(['admin@gmail.com' => $email, 'admin123' => $password])) {
        return response()->json(['message' => 'Sukses Login'], 200);
    } else {
        return response()->json(['message' => 'Login Gagal'], 401);
    }
});

Route::post('/logout', function () {
    Auth::logout();
    return response()->json(['message' => 'Sukses Logout'], 200);
});


Route::get('pelanggarans', [PelanggaranController::class, 'get']);
Route::get('pelanggaran/{id}', [PelanggaranController::class, 'get']);
Route::post('pelanggaran', [PelanggaranController::class, 'store']);
Route::put('pelanggaran/{id}', [PelanggaranController::class, 'update']);
Route::delete('pelanggaran/{id}', [PelanggaranController::class, 'destroy']);

Route::get('rpl', [RPLController::class, 'showrpl']);
Route::put('/rpl/{id}', [RPLController::class, 'updaterpl']);
Route::delete('/rpl/{id}', [RPLController::class, 'destroyrpl']);

Route::get('iop', [AllJurusanController::class, 'showiop']);
Route::put('/iop/{id}', [AllJurusanController::class, 'updateiop']);
Route::delete('/iop/{id}', [AllJurusanController::class, 'destroyiop']);

Route::get('tptu', [AllJurusanController::class, 'showtptu']);
Route::put('/tptu/{id}', [AllJurusanController::class, 'updatetptu']);
Route::delete('/tptu/{id}', [AllJurusanController::class, 'destroytptu']);

Route::get('sija', [AllJurusanController::class, 'showsija']);
Route::put('/sija/{id}', [AllJurusanController::class, 'updatesija']);
Route::delete('/sija/{id}', [AllJurusanController::class, 'destroysija']);

Route::get('toi', [AllJurusanController::class, 'showtoi']);
Route::put('/toi/{id}', [AllJurusanController::class, 'updatetoi']);
Route::delete('/toi/{id}', [AllJurusanController::class, 'destroytoi']);

Route::get('tek', [AllJurusanController::class, 'showtek']);
Route::put('/tek/{id}', [AllJurusanController::class, 'updatetek']);
Route::delete('/tek/{id}', [AllJurusanController::class, 'destroytek']);

Route::get('pspt', [AllJurusanController::class, 'showpspt']);
Route::put('/pspt/{id}', [AllJurusanController::class, 'updatepspt']);
Route::delete('/pspt/{id}', [AllJurusanController::class, 'destroypspt']);

Route::get('tei', [AllJurusanController::class, 'showtei']);
Route::put('/tei/{id}', [AllJurusanController::class, 'updatetei']);
Route::delete('/tei/{id}', [AllJurusanController::class, 'destroytei']);