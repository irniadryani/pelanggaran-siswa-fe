<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');
        
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $user = Auth::user();
           
            return response()->json(['message' => 'Sukses Login'], 200);
        }

        return response()->json(['message' => 'Invalid credentials'], 401);
    }

    public function logout(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');

        $request->user()->token()->revoke();
        return response()->json(['message' => 'Successfully logged out'], 200);
    }


    
}
