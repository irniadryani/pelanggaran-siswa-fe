<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\RPLRequest;
use App\Models\RPL;
use App\Models\Siswa;
use App\Models\Userr;
use Illuminate\Http\Request;

class RPLController extends Controller
{
    public function showrpl()
    {
            $rpl = RPL::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Rekayasa Perangkat Lunak')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($rpl);
    }

        public function store(RPLRequest $request)
        {
            // Data yang telah validasi
            $validatedData = $request->validated();
        
            // Simpan data ke dalam database
            RPL::create($validatedData);
        
            // Respon sukses atau lainnya
            return response()->json(['msg' => 'Data updated', 'data' => $rpl], 200);
        }
    
        public function updaterpl(Request $request, $id)
        {
            $rpl = RPL::find($id);
        
            if (!$rpl) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $rpl->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroyrpl($id)
        {
            $rpl = RPL::find($id);

            if (!$rpl) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }

}
