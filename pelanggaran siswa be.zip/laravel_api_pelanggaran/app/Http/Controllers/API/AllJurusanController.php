<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\AllJurusanRequest;
use App\Models\IOP;
use App\Models\MEKA;
use App\Models\TPTU;
use App\Models\SIJA;
use App\Models\TEK;
use App\Models\TOI;
use App\Models\PSPT;
use App\Models\TEI;
use App\Models\Siswa;
use App\Models\Userr;
use Illuminate\Http\Request;

class AllJurusanController extends Controller
{

    //Controller IOP
    public function showiop()
    {
            $iop = IOP::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Instrumentasi dan Otomatisasi Proses')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($iop);
    }

        public function storeiop(AllJurusanRequest $request)
        {
            // Data yang telah validasi
            $validatedData = $request->validated();
        
            // Simpan data ke dalam database
            IOP::create($validatedData);
        
            // Respon sukses atau lainnya
            return response()->json(['msg' => 'Data updated', 'data' => $iop], 200);
        }
    
        public function updateiop(Request $request, $id)
        {
            $iop = IOP::find($id);
        
            if (!$iop) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $iop->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroyiop($id)
        {
            $iop = IOP::find($id);

            if (!$iop) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


        //Controller Mekatronika

    public function showmeka()
    {
            $meka = MEKA::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Mekatronika')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($meka);
    }

        public function storemeka(AllJurusanRequest $request)
        {
            // Data yang telah validasi
            $validatedData = $request->validated();
        
            // Simpan data ke dalam database
            MEKA::create($validatedData);
        
            // Respon sukses atau lainnya
            return response()->json(['msg' => 'Data updated', 'data' => $MEKA], 200);
        }
    
        public function updatemeka(Request $request, $id)
        {
            $meka = MEKA::find($id);
        
            if (!$meka) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $meka->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroymeka($id)
        {
            $meka = MEKA::find($id);

            if (!$meka) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }




        //Controller TPTU

    public function showtptu()
    {
            $tptu = TPTU::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Teknik Pendingin dan Tata Udara')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($tptu);
    }

        public function storetptu(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TPTU::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TPTU], 200);
        }
    
        public function updatetptu(Request $request, $id)
        {
            $tptu = MEKA::find($id);
        
            if (!$meka) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $tptu->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytptu($id)
        {
            $tptu = TPTU::find($id);

            if (!$tptu) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


        //Controller SIJA

    public function showsija()
    {
            $sija = SIJA::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Sistem Jaringan dan Aplikasi')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($sija);
    }

        public function storesija(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            SIJA::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $SIJA], 200);
        }
    
        public function updatesija(Request $request, $id)
        {
            $sija = SIJA::find($id);
        
            if (!$sija) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $sija->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroysija($id)
        {
            $sija = SIJA::find($id);

            if (!$sija) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


        //Controller TEK

    public function showtek()
    {
            $tek = TEK::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Teknik Elektronika Komunikasi')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($tek);
    }

        public function storetek(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TEK::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TEK], 200);
        }
    
        public function updatetek(Request $request, $id)
        {
            $tek = TEK::find($id);
        
            if (!$tek) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $tek->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytek($id)
        {
            $tek = TEK::find($id);

            if (!$tek) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }
        

        //Controller TOI

    public function showtoi()
    {
            $toi = TOI::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Teknik Otomasi Industri')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($toi);
    }

        public function storetoi(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TOI::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TOI], 200);
        }
    
        public function updatetoi(Request $request, $id)
        {
            $toi = TOIO::find($id);
        
            if (!$toi) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $toi->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytoi($id)
        {
            $toi = TOI::find($id);

            if (!$toi) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


        //Controller PSPT

    public function showpspt()
    {
            $pspt = PSPT::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Produk Siaran Program Televisi')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($pspt);
    }

        public function storepspt(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            PSPT::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $PSPT], 200);
        }
    
        public function updatepspt(Request $request, $id)
        {
            $pspt = PSPT::find($id);
        
            if (!$pspt) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pspt->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroypspt($id)
        {
            $pspt = PSPT::find($id);

            if (!$pspt) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }

        //Controller TEI

    public function showtei()
    {
            $tei = TEI::join('siswa', 'pelanggaran.nis', '=', 'siswa.nis')
            ->join('users', 'pelanggaran.id_user', '=', 'users.id_user')
            ->where('siswa.jurusan', 'Teknik Elektronika Industri')
            ->select('siswa.nama as nama_siswa', 'siswa.kelas', 'siswa.angkatan', 'siswa.jurusan', 'users.email', 'pelanggaran.*')
            ->get();
    
        return response()->json($tei);
    }

        public function storetei(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TEI::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TEI], 200);
        }
    
        public function updatetei(Request $request, $id)
        {
            $tei = TEI::find($id);
        
            if (!$tei) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $tei->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytei($id)
        {
            $tei = TEI::find($id);

            if (!$tei) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }
}






