<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\PelanggaranRequest;
use App\Models\Pelanggaran;
use Illuminate\Http\Request;

class PelanggaranController extends Controller
{
    function get($id = null)
    {
        if (isset($id)) {
            $pelanggaran = Pelanggaran::findOrFail($id);
            return response()->json(['msg' => 'Data retrieved', 'data' => $pelanggaran], 200);
        } else {
            $pelanggaran = Pelanggaran::get();
            return response()->json(['msg' => 'Data retrieved', 'data' => $pelanggaran], 200);
        }
    }

    function store(PelanggaranRequest $request)
    {
        $pelanggaran = Pelanggaran::create($request->all());
        return response()->json(['msg' => 'Data created', 'data' => $pelanggaran], 201);
    }

    function update($id, PelanggaranRequest $request)
    {
        $pelanggaran = Pelanggaran::findOrFail($id);
        $pelanggaran->update($request->all());
        return response()->json(['msg' => 'Data updated', 'data' => $pelanggaran], 200);
    }

    function destroy($id)
    {
        $pelanggaran = Pelanggaran::findOrFail($id);
        $pelanggaran->delete();
        return response()->json(['msg' => 'Data deleted'], 200);
    }
}
