<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pelanggaran extends Model
{
    use HasFactory;
    
    protected $table        = 'pelanggaran';
    protected $primaryKey   = 'id_pelanggaran';
    protected $keyType      = 'string';
    public $incrementing    = false;
    protected $fillable     = ['id_pelanggaran', 'nis', 'jenis_pelanggaran', 'keterangan', 'id_user', 'foto'];
}
