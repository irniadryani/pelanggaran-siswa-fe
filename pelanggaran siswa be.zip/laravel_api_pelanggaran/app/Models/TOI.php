<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TOI extends Model
{
    use HasFactory;

    protected $table        = 'pelanggaran';
    protected $primaryKey   = 'id_pelanggaran';
    protected $keyType      = 'string';
    public $incrementing    = false;
    protected $fillable     = ['id_pelanggaran', 'nis', 'jenis_pelanggaran', 'keterangan', 'id_user', 'foto'];

    public function siswa()
    {
        return $this->belongsTo('App\Models\Siswa','nis');
    }

    public function user()
    {
        return $this->belongsTo(Userr::class, 'id_user');
    }
}
