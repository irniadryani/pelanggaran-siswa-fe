<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Userr extends Model
{
    use HasFactory;
    
    protected $table        = 'users';
    protected $primaryKey   = 'id_user';
    protected $keyType      = 'string';
    public $incrementing    = false;
    protected $fillable     = ['id_user', 'username', 'password', 'email'];

    // public function RPL()
    // {
    //     return $this->hasMany('App\Models\Pinjam','id_user');
    // }

    public function pelanggaran()
    {
        return $this->hasMany(Pelanggaran::class, 'id_user');
    }

}
